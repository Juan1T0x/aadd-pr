package servicios;

import java.util.ArrayList;
import java.util.List;

import modelo.Incidencia;

public class ServicioIncidencias implements IServicioIncidencias {
    private List<Incidencia> incidencias = new ArrayList<>();
    private static ServicioIncidencias instance = new ServicioIncidencias();

    private ServicioIncidencias() {}

    public static ServicioIncidencias getInstance() {
        return instance;
    }

    @Override
    public String crearIncidencia(String idBicicleta, String descripcion) {
        Incidencia incidencia = new Incidencia(idBicicleta, descripcion);
        incidencias.add(incidencia);
        return incidencia.getCodigo();
    }

    @Override
    public void gestionarIncidencia(String idIncidencia, String estado, String motivoCierre) {
        Incidencia incidencia = findIncidenciaByCodigo(idIncidencia);
        if (incidencia != null) {
            incidencia.setEstado(estado);
            incidencia.setMotivoCierre(motivoCierre);
            if (estado.equals("asignada")) {
                // Asignar operario
                incidencia.setOperarioAsignado("NombreOperario");
            }
        }
    }

    @Override
    public List<Incidencia> recuperarIncidenciasAbiertas() {
        List<Incidencia> incidenciasAbiertas = new ArrayList<>();
        for (Incidencia incidencia : incidencias) {
            if (incidencia.getEstado().equals("pendiente")) {
                incidenciasAbiertas.add(incidencia);
            }
        }
        return incidenciasAbiertas;
    }

    private Incidencia findIncidenciaByCodigo(String codigo) {
        for (Incidencia incidencia : incidencias) {
            if (incidencia.getCodigo().equals(codigo)) {
                return incidencia;
            }
        }
        return null;
    }
}