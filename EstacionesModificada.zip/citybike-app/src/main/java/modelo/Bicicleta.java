package modelo;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Bicicleta {
    private String codigo; // Código único de la bicicleta
    private String modelo;
    private Date fechaAlta;
    private Date fechaBaja; // Puede ser nulo si la bicicleta no está dada de baja
    private String motivoBaja; // Motivo de baja (nulo si no está dada de baja)
    private List<Estacion> historicoEstaciones; // Historial de estaciones por las que ha pasado
	private Estacion estacionActual;

    public Bicicleta(String modelo) {
        this.modelo = modelo;
        this.fechaAlta = new Date(); // Fecha de alta actual
        this.historicoEstaciones = new ArrayList<>();
    }

    public void setEstacion(Estacion estacion) {
        // Establece la estación actual para la bicicleta
        this.estacionActual = estacion;
    }

    public void registrarEstacionamiento() {
        // Registra el estacionamiento en la estación actual
        if (estacionActual != null) {
            estacionActual.estacionarBicicleta(this);
        }
    }
        
    
    public String getCodigo() {
        return codigo;
    }

    public String getModelo() {
        return modelo;
    }

    public Date getFechaAlta() {
        return fechaAlta;
    }

    public Date getFechaBaja() {
        return fechaBaja;
    }

    public String getMotivoBaja() {
        return motivoBaja;
    }

    public List<Estacion> getHistoricoEstaciones() {
        return historicoEstaciones;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void darDeBaja(String motivo) {
        this.fechaBaja = new Date();
        this.motivoBaja = motivo;
    }

    public void estacionar(Estacion estacion) {
        this.historicoEstaciones.add(estacion);
    }

    public void retirarDeEstacion(Estacion estacion) {
        this.historicoEstaciones.remove(estacion);
    }
}