package modelo;

import java.util.Date;

public class Incidencia {
    private String codigo;
    private String idBicicleta;
    private String descripcion;
    private Date fechaCreacion;
    private String estado;
    private String motivoCierre;
    private String operarioAsignado;

    public Incidencia(String idBicicleta, String descripcion) {
        this.idBicicleta = idBicicleta;
        this.descripcion = descripcion;
        this.fechaCreacion = new Date();
        this.estado = "pendiente";
        this.codigo = generateUniqueId();
    }

    public String getCodigo() {
        return codigo;
    }

    public String getIdBicicleta() {
        return idBicicleta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotivoCierre() {
        return motivoCierre;
    }

    public void setMotivoCierre(String motivoCierre) {
        this.motivoCierre = motivoCierre;
    }

    public String getOperarioAsignado() {
        return operarioAsignado;
    }

    public void setOperarioAsignado(String operarioAsignado) {
        this.operarioAsignado = operarioAsignado;
    }

    private String generateUniqueId() {
        return "INC-" + System.currentTimeMillis();
    }
}