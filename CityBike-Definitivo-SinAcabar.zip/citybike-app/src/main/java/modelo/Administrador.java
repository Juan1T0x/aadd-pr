package modelo;

import java.util.Date;

public class Administrador extends Usuario {


	public Administrador(String email, Date fechaNac, String telefono, String nombreCompleto) {
		super(email, fechaNac, telefono, nombreCompleto);
	}
	

}
