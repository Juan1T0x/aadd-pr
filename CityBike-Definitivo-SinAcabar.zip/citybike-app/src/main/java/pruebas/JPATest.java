package pruebas;

public class JPATest {

}
