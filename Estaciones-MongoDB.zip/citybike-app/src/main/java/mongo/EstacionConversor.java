package mongo;

import com.mongodb.client.model.geojson.Point;
import com.mongodb.client.model.geojson.Position;
import modelo.Estacion;

import java.sql.Date;
import java.util.Collections;

import org.bson.Document;

public class EstacionConversor {

    public static Document estacionToDocument(Estacion estacion) {
    	

        Document doc = new Document();
        doc.append("nombre", estacion.getNombre())
           .append("fechaAlta", estacion.getFechaAlta())
           .append("numeroPuestos", estacion.getNumeroPuestos())
           .append("direccion", estacion.getDireccion())
           .append("informacion", estacion.getInformacion());

        // Añadir la ubicación como un GeoJSON Point
        if (estacion.getLatidud() != 0 && estacion.getLongitud() != 0) {
            Point point = new Point(new Position(estacion.getLongitud(), estacion.getLatidud()));
            doc.append("ubicacion", point);
        }

        // Añade aquí otros campos que necesites

        return doc;
    }
    

    public static Estacion documentToEstacion(Document doc) {
        String id = doc.getObjectId("_id").toString();
        String nombre = doc.getString("nombre");
        Date fechaAlta = (Date) doc.getDate("fechaAlta"); // Asegúrate de manejar null si es necesario
        int numeroPuestos = doc.getInteger("numeroPuestos", 0);
        String direccion = doc.getString("direccion");
        String informacion = doc.getString("informacion");
        
        double latitud = 0.0;
        double longitud = 0.0;

        // Extraer la ubicación del GeoJSON Point
        if (doc.containsKey("ubicacion")) {
            Point point = (Point) doc.get("ubicacion");
            latitud = point.getPosition().getValues().get(1);
            longitud = point.getPosition().getValues().get(0);
        }

        // Utilizar el constructor con todos los parámetros
        return new Estacion(id, nombre, fechaAlta, numeroPuestos, direccion, latitud, longitud, informacion, Collections.emptyList());
    }
   
}
