package mongo;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Indexes;

import org.bson.Document;

public class MongoConfig {

    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "tuBaseDeDatos"; // Reemplaza con el nombre de tu base de datos
    private static final String COLLECTION_NAME = "estaciones"; // Nombre de la colección

    private MongoDatabase database;
    private MongoCollection<Document> collection;

    public MongoConfig() {
        // Crear cliente MongoDB
        try (MongoClient mongoClient = MongoClients.create(CONNECTION_STRING)) {
            // Seleccionar la base de datos
            database = mongoClient.getDatabase(DATABASE_NAME);

            // Seleccionar la colección y crear el índice geoespacial
            collection = database.getCollection(COLLECTION_NAME);
            collection.createIndex(Indexes.geo2dsphere("ubicacion"));
        }
    }

    public MongoDatabase getDatabase() {
        return database;
    }

    public MongoCollection<Document> getCollection() {
        return collection;
    }
}
    

    // Métodos adicionales para operaciones como cerrar la conexión, etc.


