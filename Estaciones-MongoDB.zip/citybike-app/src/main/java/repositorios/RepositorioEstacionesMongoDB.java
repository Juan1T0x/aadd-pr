package repositorios;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.geojson.Point;
import com.mongodb.client.model.geojson.Position;
import modelo.Estacion;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RepositorioEstacionesMongoDB implements RepositorioEstacion {
    
    private MongoCollection<Document> collection;

    public RepositorioEstacionesMongoDB(MongoDatabase database) {
        this.collection = database.getCollection("estaciones");
    }

    @Override
    public Estacion saveEstacion(Estacion estacion) {
        Document doc = estacionToDocument(estacion);
        collection.insertOne(doc);
        estacion.setId(doc.getObjectId("_id").toString());
        return estacion;
    }

    @Override
    public Estacion findEstacionById(String id) {
        Document doc = collection.find(Filters.eq("_id", new ObjectId(id))).first();
        return documentToEstacion(doc);
    }

    @Override
    public List<Estacion> getAllEstaciones() {
        List<Estacion> estaciones = new ArrayList<>();
        for (Document doc : collection.find()) {
            estaciones.add(documentToEstacion(doc));
        }
        return estaciones;
    }

    // Métodos adicionales para actualizar y eliminar

    private Document estacionToDocument(Estacion estacion) {
        // Convertir una Estacion a un Document de MongoDB
        // Incluye la conversión de la ubicación a un formato adecuado para consultas geoespaciales
        return new Document("nombre", estacion.getNombre())
                // otros campos...
                .append("ubicacion", new Document("type", "Point").append("coordinates", List.of(estacion.getLongitud(), estacion.getLatidud())));
    }

    public static Estacion documentToEstacion(Document doc) {
        String id = doc.getObjectId("_id").toString();
        String nombre = doc.getString("nombre");
        Date fechaAlta = (Date) doc.getDate("fechaAlta");
        int numeroPuestos = doc.getInteger("numeroPuestos", 0);
        String direccion = doc.getString("direccion");
        String informacion = doc.getString("informacion");
        
        double latitud = 0.0;
        double longitud = 0.0;

        // Extraer la ubicación del GeoJSON Point
        if (doc.containsKey("ubicacion")) {
            List<Double> coordinates = (List<Double>) doc.get("ubicacion", Document.class).get("coordinates");
            latitud = coordinates.get(1);
            longitud = coordinates.get(0);
        }

        // Utilizar el constructor con todos los parámetros
        // Asegúrate de proporcionar valores predeterminados o manejar null para campos opcionales
        return new Estacion(id, nombre, numeroPuestos, direccion, latitud, longitud); // Lista vacía si no hay sitios turísticos
    }
    
    public List<Estacion> encontrarEstacionesCercanas(double longitud, double latitud, double radio) {
        List<Estacion> estacionesCercanas = new ArrayList<>();
        Point refPoint = new Point(new Position(longitud, latitud));
        collection.find(Filters.near("ubicacion", refPoint, radio, 0.0))
                  .forEach(doc -> estacionesCercanas.add(documentToEstacion(doc)));
        return estacionesCercanas;
    }

    
    
}

